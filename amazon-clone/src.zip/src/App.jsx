import './App.css'
import Routing from './Router'
function App() {
 

  return <Routing/>
}

export default App
