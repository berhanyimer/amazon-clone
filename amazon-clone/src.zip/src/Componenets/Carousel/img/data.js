import img1 from "./amazon-1.jpeg";
import img2 from "./amazon-2.jpeg";
import img3 from "./amazon-3.jpeg";
import img4 from "./amazon-4.jpeg";
import img6 from "./10001.jpg";
import img7 from "./10002.jpg";
import img8 from "./10003.jpg";

import img10 from "./10006.jpg";

export const img = [img6, img2, img7, img4, img1, img10, img8, img3];
