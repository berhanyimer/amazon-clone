<CurrencyFormat
  value={total}
  displayType={"text"}
  decimalScale={2}
  thousandSeparator={true}
  prefix={"$"}
  renderText={(value) => <p>{value}</p>}
/>;
