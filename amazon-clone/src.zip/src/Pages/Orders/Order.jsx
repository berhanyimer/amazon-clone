import LayOut from '../../Componenets/Layout/LayOut'
import classes from './Order.module.css'

function Order() {
  return (
    <LayOut>
        <div> <h3>Order</h3></div>
    </LayOut>
  )
}

export default Order
