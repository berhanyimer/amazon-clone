
import LayOut from "../../Componenets/Layout/LayOut";
import classes from "./SignUp.module.css";
function SignUp() {
  return (
    <LayOut>
      <h1>LogIn</h1>
    </LayOut>
  )
}

export default SignUp
