import LayOut from "../../Componenets/Layout/LayOut"
import classes from "./Payment.module.css"

function Payment() {
  return (
    <LayOut>
      <h1>Payment</h1>
    </LayOut>
  )
}

export default Payment
